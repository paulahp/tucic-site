// ===== DADOS DO TUCIC =====

const TUCIC = {
  orixas: [
    { n: 'Oxalá',       s: 'Êbaba · Êpa Baba · Baba Okê', cor: '#F8FAFC', sig: 'O senhor realiza · Obrigado Pai · Salve Pai' },
    { n: 'Ogum',        s: 'Patacori Ogum · Ogunhê',        cor: '#DC2626', sig: 'Salve o cortador de caminhos · Salve Ogum' },
    { n: 'Xangô',       s: 'Caô Cabesilê',                  cor: '#92400E', sig: 'Permita-me vê-lo, Majestade' },
    { n: 'Oxóssi',      s: 'Okê Arô Oxóssi',                cor: '#15803D', sig: 'Dê seu brado, Majestade' },
    { n: 'Obaluaê/Omulu', s: 'Atotô',                       cor: '#334155', sig: 'Silêncio, ele está entre nós' },
    { n: 'Iemanjá',     s: 'Odôcy Iabá · Odo-fé-Iabá',     cor: '#38BDF8', sig: 'Salve a Senhora das Águas' },
    { n: 'Oxum',        s: 'Ora ie ie Oxum',                 cor: '#1D4ED8', sig: 'Olha por nós mãezinha · Salve a bondade' },
    { n: 'Iansã',       s: 'Eparrei Oiá',                   cor: '#CA8A04', sig: 'Salve o raio, Iansã' },
    { n: 'Nanã',        s: 'Saluba Nanã',                    cor: '#7C3AED', sig: 'Salve a Senhora Mãe de todas as Mães' },
    { n: 'Ibeji',       s: 'Omi Ibejada · O Doce Ibejada',  cor: '#EC4899', sig: 'Ele é dois' },
    { n: 'Oba',         s: 'Oba Xirê · Akirô Oba Yê',       cor: '#BE123C', sig: 'Eu saúdo o seu conhecimento, Senhora da Terra' },
  ],

  giras: [
    { num: '1ª', n: "Povo d'Água — Marinheiros", tipo: 'Descarrego',              desc: "Entidades muito elevadas e sutis. Chegam girando, limpando com águas e vento. Não fazem consultas. Compõe: caboclas de Oxum, Iansã, Iemanjá, Nanã e Oba." },
    { num: '2ª', n: 'Pombagira',                 tipo: 'Consultas',               desc: 'Entidades em evolução que dão consultas e fazem trabalhos de magia — união, desmanches, emprego, finanças e vida sentimental. Velas vermelhas, cigarros, bebidas doces.' },
    { num: '3ª', n: 'Xangô — Ibejada',           tipo: 'Descarrego + Consultas',  desc: 'Xangô: juízes espirituais de alta evolução, trabalham no carma e na lei espiritual. Ibejada: espíritos de grande elevação para casos de doença, família e gravidez.' },
    { num: '4ª', n: 'Boiadeiros',                tipo: 'Consultas',               desc: 'Gira de atendimento. Espíritos para evolução material e espiritual. Fazem magias com palheiro, cachaça, cerveja e velas.' },
    { num: '5ª', n: 'Ciganos',                   tipo: 'Consultas',               desc: 'Espíritos alegres para sorte, dinheiro, prosperidade e amor. Usam cartas, cristais, incensos, fumo, bebidas e flores.' },
    { num: '6ª', n: 'Exu',                       tipo: 'Consultas',               desc: 'Entidades em evolução dirigidas à defesa dos médiuns e do terreiro. Trabalham com velas pretas e vermelhas, charutos e bebidas fortes.' },
    { num: '7ª', n: 'Obaluaê/Omulu — Baianos',  tipo: 'Descarrego + Consultas',  desc: 'Omulu: energia da terra/água para saúde, não fazem consultas. Baianos: atendimentos de consulta com cigarro, cachaça e velas.' },
    { num: '8ª', n: 'Oxóssi',                    tipo: 'Descarrego + Consultas',  desc: 'Usam charutos para limpeza, tomam Curiado (vinho, água e mel). Ajudam na vida material, limpam a aura. Conselhos rápidos e práticos.' },
    { num: '9ª', n: 'Ogum — Malandros',          tipo: 'Descarrego',              desc: 'Ogum: braço forte de Oxalá no terreiro, não dão consultas. Usam charuto, cerveja, espada ou ervas. Malandros coordinados por Zé Pelintra.' },
    { num: '10ª', n: 'Pretos Velhos',            tipo: 'Consultas',               desc: 'Os psicólogos dos aflitos. Cachimbo para limpeza espiritual. Rezam doentes e crianças. Preparam patuás. Bebem café preto, consertada e cachaça com mel.' },
  ],

  linhas: [
    { n: "Linha das Águas",        d: "Caboclas de Iemanjá, Oxum, Obá, Iansã e Nanã", c: '#38BDF8' },
    { n: "Linha de Ibejada",       d: "Erês — Crianças de Ibeji",                      c: '#EC4899' },
    { n: "Linha das Almas",        d: "Obaluaê/Omulu, Pretos Velhos",                  c: '#475569' },
    { n: "Linha de Ogum",          d: "Caboclos ou Falangeiros de Ogum",                c: '#DC2626' },
    { n: "Linha de Oxossi",        d: "Caboclos de Oxóssi",                             c: '#15803D' },
    { n: "Linha de Xangô",         d: "Caboclos de Xangô",                              c: '#92400E' },
    { n: "Linha de Ciganos",       d: "Espíritos ciganos e suas tradições",              c: '#D97706' },
    { n: "Linha do Povo do Oriente", d: "Espíritos elevados de cura e saúde",           c: '#EA580C' },
    { n: "Linha de Boiadeiros",    d: "Espíritos da boiada e do campo",                 c: '#78350F' },
    { n: "Linha de Marinheiros",   d: "Povo d'água — marinheiros e piratas",            c: '#1D4ED8' },
    { n: "Linha de Malandros",     d: "Coordenada por Zé Pelintra",                     c: '#9F1239' },
    { n: "Linha da Esquerda",      d: "Exu, Pomba-Gira e Mirim",                        c: '#1E293B' },
    { n: "Linha de Baianos",       d: "Baianos e suas correntes",                       c: '#B45309' },
  ],

  setteLinhas: [
    { n: 'Oriente',       o: 'Oxalá',             v: 'FÉ',                          c: '#EA580C', d: 'Engloba todas as entidades de cura' },
    { n: 'Ogum',          o: 'Ogum',              v: 'LEI · ORDENAÇÃO',             c: '#DC2626', d: 'Linha da lei e da ordenação espiritual' },
    { n: 'Xangô',         o: 'Xangô',             v: 'JUSTIÇA · JULGAMENTO · RAZÃO',c: '#92400E', d: 'Linha da justiça e do julgamento espiritual' },
    { n: "Oxóssi",        o: 'Oxóssi',            v: 'DOUTRINA · CONHECIMENTO',     c: '#15803D', d: 'Linha de Caboclos Doutrinadores' },
    { n: "Povo d'Água",   o: 'Iemanjá, Oxum, Iansã, Nanã', v: 'AMOR · GERAÇÃO',   c: '#38BDF8', d: 'Linha das Mães e do amor universal' },
    { n: 'Almas',         o: 'Obaluaê/Omulú',     v: 'EVOLUÇÃO · HUMILDADE',        c: '#7C3AED', d: 'Linha de Evolução' },
    { n: 'Ibejada/Erês',  o: 'Ibeji',             v: 'INOCÊNCIA · ALEGRIA · SAÚDE', c: '#EC4899', d: 'Linha das Crianças' },
  ],
};

// ===== AUTENTICAÇÃO SIMULADA =====
// ATENÇÃO: Em produção, substituir por autenticação real (Supabase, Firebase, etc.)
const USERS = {
  'admin@tucic.com':  { pass: 'tucic2024', name: 'Mãe Rosi de Oxum', role: 'ADMINISTRADORA', ini: 'MR', admin: true },
  'membro@tucic.com': { pass: 'tucic2024', name: 'Membro TUCIC',      role: 'MEMBRO',         ini: 'MT', admin: false },
};

// ===== ESTADO DA SESSÃO =====
let currentUser = null;

function getSession() {
  try {
    const s = sessionStorage.getItem('tucic_user');
    return s ? JSON.parse(s) : null;
  } catch { return null; }
}

function setSession(user) {
  sessionStorage.setItem('tucic_user', JSON.stringify(user));
}

function clearSession() {
  sessionStorage.removeItem('tucic_user');
}

// ===== UTILITÁRIOS =====

function el(id) { return document.getElementById(id); }

function showPage(id) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  const page = el('page-' + id);
  if (page) page.classList.add('active');
}

function showSection(id, navEl) {
  document.querySelectorAll('.section-content').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  const sec = el('sec-' + id);
  if (sec) sec.classList.add('active');
  if (navEl) navEl.classList.add('active');
  // scroll to top on mobile
  const main = document.querySelector('.main-content');
  if (main) main.scrollTop = 0;
}

function showTab(group, tabId, tabEl) {
  const prefix = 'tab-' + group + '-';
  document.querySelectorAll('[id^="' + prefix + '"]').forEach(t => t.classList.remove('active'));
  const t = el(prefix + tabId);
  if (t) t.classList.add('active');
  if (tabEl) {
    tabEl.closest('.tabs').querySelectorAll('.tab').forEach(tab => tab.classList.remove('active'));
    tabEl.classList.add('active');
  }
}

// ===== BUILDER DINÂMICO =====

function buildOrixas() {
  const grid = el('orixas-grid');
  if (!grid) return;
  grid.innerHTML = '';
  TUCIC.orixas.forEach((o, i) => {
    const card = document.createElement('div');
    card.className = 'orixa-card';
    card.innerHTML = `<span class="orixa-dot" style="background:${o.cor}"></span>
      <div class="orixa-name">${o.n}</div>
      <div class="orixa-saud">${o.s}</div>`;
    card.addEventListener('click', () => showOrixaDetail(i));
    grid.appendChild(card);
  });
}

function showOrixaDetail(i) {
  const o = TUCIC.orixas[i];
  const det = el('orixa-detail');
  if (!det) return;
  det.innerHTML = `<div class="rc">
    <div class="rc-title">${o.n}</div>
    <div class="rc-meta">Saudação</div>
    <div style="margin-bottom:8px;">
      <span class="orixa-dot" style="background:${o.cor};display:inline-block;"></span>
      <strong style="color:var(--dourado-v);font-size:13px;margin-left:4px;">${o.s}</strong>
    </div>
    <div class="rc-body">Significado: ${o.sig}</div>
  </div>`;
  det.style.display = 'block';
  det.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function buildGiras() {
  const seq = el('giras-seq');
  const fund = el('giras-fund');
  if (!seq || !fund) return;
  seq.innerHTML = '';
  fund.innerHTML = '';
  TUCIC.giras.forEach(g => {
    seq.innerHTML += `<div class="gira-item">
      <div class="gira-num">${g.num} GIRA</div>
      <div class="gira-title">${g.n}</div>
      <div class="gira-desc"><span class="badge">${g.tipo}</span></div>
    </div>`;
    fund.innerHTML += `<div class="gira-item">
      <div class="gira-num">${g.num} GIRA · ${g.tipo.toUpperCase()}</div>
      <div class="gira-title">${g.n}</div>
      <div class="gira-desc">${g.desc}</div>
    </div>`;
  });
}

function buildLinhas() {
  const trab = el('linhas-trab');
  const sete = el('linhas-sete');
  if (!trab || !sete) return;
  trab.innerHTML = '';
  sete.innerHTML = '';
  TUCIC.linhas.forEach(l => {
    trab.innerHTML += `<div class="list-item">
      <div class="list-dot" style="background:${l.c}"></div>
      <div><div style="font-size:12px;font-weight:700;color:var(--dourado-v);margin-bottom:1px;">${l.n}</div>
      <div class="list-text">${l.d}</div></div>
    </div>`;
  });
  TUCIC.setteLinhas.forEach(l => {
    sete.innerHTML += `<div class="list-item">
      <div class="list-dot" style="background:${l.c};flex-shrink:0;"></div>
      <div>
        <div style="font-size:12px;font-weight:700;color:var(--dourado-v);margin-bottom:1px;">
          ${l.n} <span style="font-size:9px;color:rgba(255,215,0,.35);">${l.o}</span>
        </div>
        <div class="list-text"><strong style="color:var(--dourado-v);font-size:10px;">${l.v}</strong><br>${l.d}</div>
      </div>
    </div>`;
  });
}

function buildDashboard() {
  buildOrixas();
  buildGiras();
  buildLinhas();
}

// ===== ADMIN =====

function approveRow(btn) {
  const row = btn.closest('tr');
  row.querySelector('td:nth-child(4)').className = 'status-active';
  row.querySelector('td:nth-child(4)').textContent = '✓ Ativo';
  row.querySelector('td:nth-child(5)').innerHTML = '—';
}

function rejectRow(btn) {
  const row = btn.closest('tr');
  row.style.opacity = '.35';
  row.querySelector('td:nth-child(4)').textContent = '✗ Recusado';
  row.querySelector('td:nth-child(5)').innerHTML = '—';
}
