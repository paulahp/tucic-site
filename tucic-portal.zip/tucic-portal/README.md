# 🌿 TUCIC — Portal dos Membros

Portal sagrado e fechado para membros da **Tenda de Umbanda Cabocla Inaê das Cachoeiras**.

**Dirigido por:** Mãe Rosi de Oxum  
**Localidade:** Florianópolis/SC

---

## 📁 Estrutura do Projeto

```
tucic-portal/
├── index.html          → Landing page pública
├── login.html          → Página de login
├── solicitar.html      → Formulário de solicitação de acesso
├── dashboard.html      → Área dos membros (protegida)
├── css/
│   └── style.css       → Estilos globais
├── js/
│   └── data.js         → Dados do terreiro + autenticação
└── README.md
```

---

## 🚀 Como publicar no GitHub Pages

### 1. Criar repositório no GitHub

```bash
git init
git add .
git commit -m "feat: portal inicial TUCIC"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/tucic-portal.git
git push -u origin main
```

### 2. Ativar GitHub Pages

1. Acesse o repositório no GitHub
2. Vá em **Settings → Pages**
3. Em "Source", selecione **Deploy from a branch**
4. Escolha a branch **main** e pasta **/ (root)**
5. Clique em **Save**
6. Aguarde alguns minutos — o site estará em:  
   `https://SEU_USUARIO.github.io/tucic-portal/`

---

## 🔐 Autenticação

> ⚠️ A autenticação atual é **simulada via JavaScript** — apenas para prototipagem.
> Em produção, substitua por um backend real.

### Opções recomendadas para produção:

| Opção | Custo | Facilidade |
|-------|-------|------------|
| **Supabase** (recomendado) | Gratuito até certo limite | ⭐⭐⭐⭐ |
| **Firebase Auth** | Gratuito | ⭐⭐⭐ |
| **Netlify Identity** | Gratuito até 1000 usuários | ⭐⭐⭐⭐⭐ |

### Credenciais de demonstração atuais:
```
Admin:  admin@tucic.com  / tucic2024
Membro: membro@tucic.com / tucic2024
```

**Para remover as credenciais de demonstração:**  
No arquivo `login.html`, remova o parágrafo com classe `auth-hint`.  
No arquivo `js/data.js`, esvazie o objeto `USERS` e integre com o backend escolhido.

---

## 📬 Formulário de Solicitação de Acesso

Atualmente o formulário (`solicitar.html`) apenas simula o envio.  
Para receber as solicitações por e-mail, use uma destas opções:

### Opção 1 — FormSubmit (mais simples, gratuito)

No `solicitar.html`, substitua a função `enviarSolicitacao()` por um `<form>` HTML:

```html
<form action="https://formsubmit.co/SEU_EMAIL@gmail.com" method="POST">
  <!-- seus campos aqui -->
  <input type="hidden" name="_subject" value="Nova solicitação de acesso - TUCIC">
  <input type="hidden" name="_next" value="https://seusite.com/pendente.html">
  <button type="submit">Enviar Solicitação</button>
</form>
```

### Opção 2 — Netlify Forms (se hospedar no Netlify)

Adicione `netlify` ao `<form>` e um campo hidden `form-name`.

---

## 🎨 Customização

### Cores principais (em `css/style.css`):
```css
--dourado: #B8860B;       /* Dourado base */
--dourado-brilho: #FFD700; /* Dourado brilhante */
--azul: #1E3A8A;           /* Azul bic */
--bg: #0B1730;             /* Fundo principal */
```

### Adicionar novo conteúdo:
- Para novas seções no dashboard: adicione um `<section id="sec-NOME">` em `dashboard.html`
- Adicione o link no menu sidebar com `onclick="showSection('NOME', this)"`
- Para dados dinâmicos (orixás, giras, linhas): edite o objeto `TUCIC` em `js/data.js`

---

## 📱 Responsividade

O portal é responsivo para mobile. Em telas pequenas, a sidebar se transforma em uma barra horizontal de navegação.

---

## ✨ Axé!

Desenvolvido com amor e respeito para o Terreiro TUCIC.  
Que Inaê das Cachoeiras abra os caminhos. 🌿
